package edu.famu.gsdatabase.models;

import edu.famu.gsdatabase.models.AGameContent;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class Gamecontent extends AGameContent {
   // private Users creator;

    /*public Gamecontent(String contentId,String description,boolean exclusive,double rating, String status,List<String> tags, String title,String type,long views, String creator){
        super(contentId,description, rating,status,tags, title,type,views);
        this.creator = creator;
    }*/
}
