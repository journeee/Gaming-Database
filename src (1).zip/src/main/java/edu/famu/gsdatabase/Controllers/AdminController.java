package edu.famu.gsdatabase.Controllers;


import edu.famu.gsdatabase.service.GameContentService;
import edu.famu.gsdatabase.service.UsersService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("api/admin")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {

    @Autowired
    private GameContentService gameContentService;

    @Autowired
    private UsersService usersService;

    public AdminController(GameContentService gameContentService, UsersService usersService) {
        this.gameContentService = gameContentService;
        this.usersService = usersService;
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/report")
    public ResponseEntity<ApiResponseFormat<Map<String, Object>>> generateAdminReport() {
        try {
            Map<String, Object> report = usersService.generateAdminReport();
            return ResponseEntity.ok(new ApiResponseFormat<>(true, "Admin report generated successfully", report, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error generating admin report", null, e.getMessage()));
        }
    }
}
