package edu.famu.gsdatabase.Controllers;


import edu.famu.gsdatabase.models.Logs;
import edu.famu.gsdatabase.service.LogsService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("api/logs")
@CrossOrigin(origins = "http://localhost:3000")
public class LogsController {
    private LogsService logsService;

    public LogsController(LogsService logsService) {
        this.logsService = logsService;
    }

    @GetMapping("/")
    public ResponseEntity<ApiResponseFormat<List<Logs>>> getAllLogs() {
        try {
            List<Logs> logList = logsService.getAllLogs();
            if (!logList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "Logs retrieved successfully", logList, "200"));
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body(new ApiResponseFormat<>(true, "No logs found", null, null));
            }
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving logs", null, e.getMessage()));
        }
    }

    @PostMapping("/")
    public ResponseEntity<ApiResponseFormat<String>> addLog(@RequestBody Logs log) {
        try {
            String id = logsService.createLog(log);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponseFormat<>(true, "Log created successfully", id, null));
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error creating log", null, e.getMessage()));
        }
    }
}

