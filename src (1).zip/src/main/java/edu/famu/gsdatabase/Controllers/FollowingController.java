package edu.famu.gsdatabase.Controllers;


import edu.famu.gsdatabase.models.Following;
import edu.famu.gsdatabase.service.FollowingService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("api/following")
public class FollowingController {
    private FollowingService followingService;

    public FollowingController(FollowingService followingService){
        this.followingService = followingService;
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/")
    public ResponseEntity<ApiResponseFormat<List<Following>>> getAllFollowers(){

        try {
            List<Following> followingList = followingService.getAllFollowing();
            if(!followingList.isEmpty())
                return  ResponseEntity.ok(new ApiResponseFormat<>(true,"GameContent retrieved successfully", followingList, "500"));
            else
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body(new ApiResponseFormat<>(true,null,null,null));
        }
        catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving followerList", null, e.getMessage()));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{username}")
    public ResponseEntity<ApiResponseFormat<Following>> getFollowingByUser(@PathVariable String username) {
        try {
            Following following = followingService.getFollowingByUser(username);
            if (following != null) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "User retrieved successfully", following, null));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ApiResponseFormat<>(false, "User not found", null, null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving user", null, e.getMessage()));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/")
    public  ResponseEntity<ApiResponseFormat<String>> addFollower (@RequestBody Following following){
        try {
            String id = followingService.createFollowing(following);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponseFormat<>(true, "Following list successfully created", id, null));
        }
        catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error creating Following list", null, e));
        }

    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{user}")
    public ResponseEntity<ApiResponseFormat<String>> updateFollowing(@PathVariable String user, @RequestBody Following following) {
        try {
            followingService.updateFollowing(user, following);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "Following list updated successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error updating Following list", null, e));
        }
    }
}
