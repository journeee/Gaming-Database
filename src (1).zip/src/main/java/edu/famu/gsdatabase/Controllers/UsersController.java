package edu.famu.gsdatabase.Controllers;

import com.google.cloud.firestore.WriteResult;

import edu.famu.gsdatabase.models.Gamecontent;
import edu.famu.gsdatabase.models.Users;
import edu.famu.gsdatabase.service.UsersService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import edu.famu.gsdatabase.util.Utility;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("api/users")
public class UsersController {
    // http://localhost:8080/api/users

    private UsersService usersService;

    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/")
    public ResponseEntity<ApiResponseFormat<List<Users>>> getAllUsers() {
        try {
            List<Users> userList = usersService.getAllUsers();
            if (!userList.isEmpty())
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "User retrieved successfully", userList, "500"));
            else
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body(new ApiResponseFormat<>(true, null, null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving users", null, e.getMessage()));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponseFormat<Users>> getUserById(@PathVariable String userId) {
        try {
            Users user = usersService.getUserById(userId);
            if (user != null) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "User retrieved successfully", user, null));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ApiResponseFormat<>(false, "User not found", null, null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving user", null, e.getMessage()));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{username}/{password}")
    public ResponseEntity<ApiResponseFormat<Users>> getUserByUsernamePassword(@PathVariable String username, @PathVariable String password) {
        try {
            Users user = usersService.getUserByUsernamePassword(username, password);
            if (user != null) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "User retrieved successfully", user, null));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ApiResponseFormat<>(false, "User not found", null, null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving user", null, e.getMessage()));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping(value = "/", produces = Utility.DEFAULT_MEDIA_TYPE, consumes = Utility.DEFAULT_MEDIA_TYPE)
    public  ResponseEntity<ApiResponseFormat<String>> addUser (@RequestBody Users user){
        try {
            String id = usersService.createUser(user);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponseFormat<>(true, "User successfully created", id, null));
        }
        catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error creating users", null, e));
        }

    }

    @CrossOrigin(origins = "http://localhost:3000")
    @DeleteMapping("/{username}")
    public ResponseEntity<ApiResponseFormat<String>> deleteUserByUsername(@PathVariable String username) {
        try {
            usersService.removeUserByUsername(username);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "User deleted successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error deleting user", null, e));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponseFormat<>(false, e.getMessage(), null, null));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{userId}")
    public ResponseEntity<ApiResponseFormat<String>> updateUser(@PathVariable String userId, @RequestBody Users user) {
        try {
            usersService.updateUser(userId, user);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "User updated successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error updating user", null, e));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{userId}/status")
    public ResponseEntity<ApiResponseFormat<String>> updateUserStatus(@PathVariable String userId, @RequestBody Map<String, String> updates) {
        try {
            String status = updates.get("status");
            usersService.updateUserStatus(userId, status);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "User status updated successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error updating user status", null, e));
        }
    }


    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{username}/follow/{creatorUsername}")
    public ResponseEntity<?> updateFollowing(@PathVariable String username, @PathVariable String creatorUsername) {
        try {
            usersService.updateFollowing(username, creatorUsername);
            return ResponseEntity.ok().build();
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating following list");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{username}/unfollow/{creatorUsername}")
    public ResponseEntity<ApiResponseFormat<Void>> unfollowUser(
                @PathVariable String username,
                @PathVariable String creatorUsername) {
            try {
                System.out.println("Received unfollow request: " + username + " unfollowing " + creatorUsername);
                WriteResult result = usersService.unfollowUser(username, creatorUsername);
                if (result != null) {
                    return ResponseEntity.ok(new ApiResponseFormat<>(true, "User unfollowed successfully", null, null));
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new ApiResponseFormat<>(false, "User not found", null, null));
                }
            } catch (ExecutionException | InterruptedException e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ApiResponseFormat<>(false, "Error unfollowing user", null, e.getMessage()));
            }
    }




    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/username/{username}")
    public ResponseEntity<ApiResponseFormat<Users>> getUserByUsername(@PathVariable String username) {
        try {
            Users user = usersService.getUserByUsername(username);
            if (user != null)
            {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "User retrieved successfully", user, null));
            } else
            {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ApiResponseFormat<>(false, "User not found", null, null));
            }
        } catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving user", null, e.getMessage()));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{username}/following")
    public ResponseEntity<?> getFollowing(@PathVariable String username) {
        try {
            List<String> following = usersService.getFollowing(username);
            return ResponseEntity.ok(following);
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving following list");
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{userId}/bookmark")
    public ResponseEntity<ApiResponseFormat<List<Gamecontent>>> getUserBookmarks(@PathVariable String userId) {
        try {
            List<Gamecontent> bookmarks = usersService.getUserBookmarks(userId);
            if (bookmarks != null && !bookmarks.isEmpty()) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "Bookmarks retrieved successfully", bookmarks, null));
            } else {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "No bookmarks found for user", new ArrayList<>(), null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving bookmarks", null, e.getMessage()));
        }
    }


    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/{userId}/bookmark/{contentId}")
    public ResponseEntity<ApiResponseFormat<String>> addBookmark(@PathVariable String userId, @PathVariable String contentId) {
        try {
            usersService.addBookmark(userId, contentId);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "Bookmark added successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error adding bookmark", null, e.getMessage()));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @DeleteMapping("/{userId}/bookmark/{contentId}")
    public ResponseEntity<ApiResponseFormat<String>> removeBookmark(@PathVariable String userId, @PathVariable String contentId) {
        try {
            usersService.removeBookmark(userId, contentId);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponseFormat<>(true, "Bookmark removed successfully", null, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error removing bookmark", null, e.getMessage()));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @RequestMapping("api/admin")
    public class AdminController {
        private final UsersService usersService;
        public AdminController(UsersService usersService) {
            this.usersService = usersService;
        }
        @GetMapping("/report")
        public ResponseEntity<ApiResponseFormat<Map<String, Object>>> getAdminReport() {
            try {
                Map<String, Object> report = new HashMap<>();
                report.put("engagementMetrics", usersService.getEngagementMetrics());
                report.put("contentInteractionMetrics", usersService.getContentInteractionMetrics());
                report.put("subscriptionTrends", usersService.getSubscriptionTrends());

                return ResponseEntity.ok(new ApiResponseFormat<>(true, "Admin report generated successfully", report, null));
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ApiResponseFormat<>(false, "Error generating admin report", null, e.getMessage()));
            }
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/admin/report")
    public ResponseEntity<ApiResponseFormat<Map<String, Object>>> generateAdminReport() {
        try {
            Map<String, Object> report = usersService.generateAdminReport();
            return ResponseEntity.ok(new ApiResponseFormat<>(true, "Admin report generated successfully", report, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error generating admin report", null, e.getMessage()));
        }
    }

}



