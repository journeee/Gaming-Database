package edu.famu.gsdatabase.Controllers;


import com.google.cloud.firestore.WriteResult;

import edu.famu.gsdatabase.models.Gamecontent;
import edu.famu.gsdatabase.service.GameContentService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import static org.glassfish.hk2.utilities.reflection.Pretty.collection;

@RestController
@RequestMapping("api/gameContent")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class GameContentController {


    @Autowired
    private GameContentService gameContentService;

    public GameContentController(GameContentService gameContentService){
        this.gameContentService = gameContentService;
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/")
    public ResponseEntity<ApiResponseFormat<List<Gamecontent>>> getAllGameContent() {
        try {
            List<Gamecontent> gameContentList = gameContentService.getAllGameContent();
            if (!gameContentList.isEmpty()) {
                return ResponseEntity.ok(new ApiResponseFormat<>(true, "GameContent retrieved successfully", gameContentList, "500"));
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body(new ApiResponseFormat<>(true, null, null, null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving GameContent", null, e.getMessage()));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{contentId}")
    public ResponseEntity<ApiResponseFormat<WriteResult>> updateGameContent(@PathVariable("contentId") String id,
                                                                             @RequestBody Map<String, Object> updateValues, @RequestParam String moderatorUsername) {
        try {
            WriteResult result = gameContentService.updateGameContent(id, updateValues, moderatorUsername);
            return ResponseEntity.accepted()
                    .body(new ApiResponseFormat<>(true, "Content successfully updated", result, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error updating content", null, e.getMessage()));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000") @PostMapping("/")
    public ResponseEntity<ApiResponseFormat<String>> addGameContent(@RequestBody Gamecontent gameContent) {
        try {
            String id = gameContentService.createGameContent(gameContent);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponseFormat<>(true, "Game content successfully created", id, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error creating Game content", null, e));
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @DeleteMapping(path = "/{Id}")
    public ResponseEntity<ApiResponseFormat<WriteResult>> deleteUser(@PathVariable(name = "Id") String contentId) {
        try {
            WriteResult result = gameContentService.removeContent(contentId);
            return ResponseEntity.ok(new ApiResponseFormat<>(true, "Content deleted", result, null));
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error deleting content", null, e));
        }
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseFormat<Gamecontent>> getGameContentById(@PathVariable String id) {
        Optional<Gamecontent> gameContent = gameContentService.getGameContentById(id);
        if (gameContent.isPresent()) {
            return ResponseEntity.ok(new ApiResponseFormat<>(true, "GameContent found", gameContent.get(), null));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponseFormat<>(false, "GameContent not found", null, null));
        }
    }

}

