package edu.famu.gsdatabase.Controllers;


import edu.famu.gsdatabase.models.Comments;
import edu.famu.gsdatabase.service.CommentsService;
import edu.famu.gsdatabase.util.ApiResponseFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.ExecutionException;
@RestController
@RequestMapping("api/comments")
public class CommentsController {

    private CommentsService commentService;

    public CommentsController(CommentsService commentService){
        this.commentService = commentService;
    }

    @GetMapping("/")
    public ResponseEntity<ApiResponseFormat<List<Comments>>> getAllComments(){

        try {
            List<Comments> commentList = commentService.getAllComments();
            if(!commentList.isEmpty())
                return  ResponseEntity.ok(new ApiResponseFormat<>(true,"GameContent retrieved successfully", commentList, "500"));
            else
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body(new ApiResponseFormat<>(true,null,null,null));
        }
        catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponseFormat<>(false, "Error retrieving GameContent", null, e.getMessage()));
        }
    }
}
