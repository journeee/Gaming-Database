package edu.famu.gsdatabase.Controllers;


import edu.famu.gsdatabase.models.Users;
import edu.famu.gsdatabase.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private UsersService usersService;
@CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserCredentials userCredentials) {
        try {
            Users user = usersService.getUserByUsernamePassword(userCredentials.getUsername(), userCredentials.getPassword());
            if (user != null) {
                return ResponseEntity.ok(new AuthResponse(true, "Login successful", user));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new AuthResponse(false, "Invalid username or password", null));
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new AuthResponse(false, "Server error", null));
        }
    }
}

class UserCredentials {
    private String username;
    private String password;

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

class AuthResponse {
    private boolean success;
    private String message;
    private Users user;

    public AuthResponse(boolean success, String message, Users user) {
        this.success = success;
        this.message = message;
        this.user = user;
    }

    // Getters
    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Users getUser() {
        return user;
    }
}

